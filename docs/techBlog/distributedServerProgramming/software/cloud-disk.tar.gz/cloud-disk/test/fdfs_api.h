#ifndef _FDFS_API_H
#define _FDFS_API_H

int fdfs_upload_file(const char* filename, char* fileid);
int fdfs_upload_file1(const char* filename, char* fileid, int size);

#endif
    
